/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int main()
{
    int n1,n2,max;
    printf("enter two numbers:");
    scanf("%d%d",&n1,&n2);
    max=(n1>n2)?n1:n2;
    while(1){
        if((max%n1==0)&&(max%n2==0))
    {
    printf("the lcm is:%d",max);
    break;
}
max++;
}
return 0;
}