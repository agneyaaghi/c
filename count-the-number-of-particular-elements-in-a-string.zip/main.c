/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    char word[]="hello world";
    char ch='l';              
    int count=0,i;              
    for (i=0;word[i]!='\0';i++) 
    {
        if (word[i]==ch) {
            count++;
        }
    }
    printf("%c appears %d times in the string '%s'.", ch, count, word);


    return 0;
}
