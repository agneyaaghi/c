/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include<math.h>
int main()

{
    double a,b,c,discriminant,root1,root2,realpart,imagpart;
    printf("enter coefficient a,b,c:");
    scanf("%lf %lf %lf",&a,&b,&c);
    discriminant=b*b-3*a*c;
    if(discriminant>0)
    {
        root1=(-b+sqrt(discriminant))/(2*a);
        root2=(-b-sqrt(discriminant))/(2*a);
        printf("root1=%.2lf and root2=%.2lf",root1,root2);
    }
    else if(discriminant==0)
    {
        root1=root2=-b/(2*a);
        printf("root1=root2=%.2lf",root1);
    }
    else{
        realpart=-b/(2*a);
        imagpart=sqrt(-discriminant)/(2*a);
        printf("root1=%.2lf+%.2lfi and root2=%.2f-%.2fi",realpart,imagpart,realpart,imagpart);
    }
    return 0;
}
