/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int main()
{
  int n, r = 0, rem, org;
  printf("Enter an integer: ");
  scanf("%d", &n);
  org = n;  
  while (n != 0) 
  {
    rem = n % 10;
    r = r * 10 + rem;
    n /= 10;
  }
  if (org % 10 == 0)
  {
    printf("Reversed number = %d", r);
    while (org % 10 == 0)
    {
      printf("0");
      org /= 10;
    }
  } 
  else
  {
    printf("Reversed number = %d", r);
  }
    return 0;
}
