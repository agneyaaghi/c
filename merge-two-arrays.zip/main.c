/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int main()
{
    int a[50], b[50], merged[100], n1, n2, i;
    printf("Enter the size of the first array : ");
    scanf("%d", &n1);
    printf("Enter elements for the first array :");
    for(i = 0; i < n1; i++)
    {
    scanf("%d", &a[i]);
    }
    printf("Enter the size of the second array : ");
    scanf("%d", &n2);
    printf("Enter elements for the second array :");
    for(i=0;i<n2;i++) 
    {
    scanf("%d",&b[i]);
    }
    for(i=0;i<n1;i++)
    {
        merged[i] = a[i]; 
    }
    for(i = 0; i < n2; i++) 
    {
        merged[n1+i] = b[i];
    }
    printf("Merged array is:\n");
    for(i = 0; i < n1 + n2; i++) 
    {
        printf("%d ", merged[i]);
    }
    return 0;
}
