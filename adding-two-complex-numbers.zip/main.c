/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int main()

{
   int real1,imaginary1,real2,imaginary2,sumofreal,sumofimaginary;
   printf("enter complex number one(real and imaginary):");
   scanf("%d%d",&real1,&imaginary1);
   printf("enter complex number two(real and imaginary):");
   scanf("%d%d",&real2,&imaginary2);
   sumofreal=real1+real2;
   sumofimaginary=imaginary1+imaginary2;
   printf("sum : %d %di",sumofreal,sumofimaginary);
   return 0;
}
