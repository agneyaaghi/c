/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAX_BOOKS 100
#define MAX_NAME_LENGTH 100
typedef struct {
    int id;
    char name[MAX_NAME_LENGTH];
    char author[MAX_NAME_LENGTH];
    float price;
}
Book;
Book inventory[MAX_BOOKS];
int bookCount = 0;
void addBook() {
    if (bookCount >= MAX_BOOKS) {
        printf("Inventory is full. Cannot add more books.\n");
        return;
    }
    Book newBook;
    int i, exists = 0;
    printf("Enter book ID: ");
    scanf("%d", &newBook.id);
    for (i = 0; i < bookCount; i++) {
        if (inventory[i].id == newBook.id) {
            printf("Book ID already exists.\n");
            exists = 1;
            break;
        }
    }
    if (exists) return;
    printf("Enter book name: ");
    scanf(" %[^\n]s", newBook.name); 
    printf("Enter author name: ");
    scanf(" %[^\n]s", newBook.author);
    printf("Enter book price: ");
    scanf("%f", &newBook.price);
    inventory[bookCount++] = newBook;
    printf("Book added successfully.\n");
}
void viewBooks() {
    if (bookCount == 0) {
        printf("No books in the inventory.\n");
        return;
    }
    printf("Book ID\tName\tAuthor\tPrice\n");
    for (int i = 0; i < bookCount; i++) {
        printf("%d\t%s\t%s\t%.2f\n", inventory[i].id, inventory[i].name, inventory[i].author, inventory[i].price);
    }
}
void updatePrice() {
    int id, i, found = 0;
    printf("Enter book ID to update price: ");
    scanf("%d", &id);
    for (i = 0; i < bookCount; i++) {
        if (inventory[i].id == id) {
            printf("Current price: %.2f\n", inventory[i].price);
            printf("Enter new price: ");
            scanf("%f", &inventory[i].price);
            printf("Price updated successfully.\n");
            found = 1;
            break;
        }
    }
    if (!found) {
        printf("Book ID not found.\n");
    }
}
void deleteBook() {
    int id, i, j, found = 0;
    printf("Enter book ID to delete: ");
    scanf("%d", &id);
    for (i = 0; i < bookCount; i++) {
        if (inventory[i].id == id) {
            for (j = i; j < bookCount - 1; j++) {
                inventory[j] = inventory[j + 1];
            }
            bookCount--;
            printf("Book deleted successfully.\n");
            found = 1;
            break;
        }
    }
    if (!found) {
        printf("Book ID not found.\n");
    }
}
int main() {
    int choice;
    do {
        printf("\nBook Inventory Menu:\n");
        printf("1. Add a book\n");
        printf("2. View books\n");
        printf("3. Update price\n");
        printf("4. Delete a book\n");
        printf("5. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);
        switch (choice) {
            case 1:
                addBook();
                break;
            case 2:
                viewBooks();
                break;
            case 3:
                updatePrice();
                break;
            case 4:
                deleteBook();
                break;
            case 5:
                printf("Exiting program.\n");
                break;
            default:
                printf("Invalid choice. Please try again.\n");
                break;
        }
    } while (choice != 5);

    return 0;
}
