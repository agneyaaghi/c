/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int n,i,j=0;
    printf("Enter the number of elements : ");
    scanf("%d",&n);
    int arr[n];
    int even[n];
    printf("Enter the elements : ");
    for(i=0;i<n;i++) {
        scanf("%d",&arr[i]);
    }
    for(i=0;i<n;i++) 
    {
        if(arr[i]%2==0)
        {
            even[j++]=arr[i];
        }
    }
    printf("Even numbers in the array are : ");
    for(i=0;i<j;i++) 
    {
        printf("%d ",even[i]);
    }

    return 0;
}
