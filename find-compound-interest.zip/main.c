/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<stdio.h>
#include<math.h>
int main()
{
    double p, r, a;
    int times_compounded, years;
    printf("Enter the principal amount: ");
    scanf("%lf", &p);
    printf("Enter the annual interest rate : ");
    scanf("%lf", &r);
    printf("Enter the number of time  interest is compounded per year: ");
    scanf("%d", &times_compounded);
    printf("Enter the number of years : ");
    scanf("%d", &years);
    r = r / 100.0;
    a = p * pow((1 + r / times_compounded), times_compounded * years);
    printf("The amount of money accumulated after %d years is : %.2lf\n", years, a);
    return 0;
}
