/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int main()
{
        int number[30];
        int i, j, a, n;
        printf("Enter the num  : ");
        scanf("%d", &n);
        printf("Enter the numbers : ");
        for (i = 0; i < n; ++i)
	    scanf("%d", &number[i]);
        for (i = 0; i < n; ++i) 
        {
            for (j = i + 1; j < n; ++j) 
            {
                if (number[i] < number[j]) 
                {
                    a = number[i];
                    number[i] = number[j];
                    number[j] = a;
                }
            }
        }
        printf("The numbers arranged in descending order : ");
        for (i = 0; i < n; ++i) 
        {
            printf(" %d ", number[i]);
        }
    return 0;
}
