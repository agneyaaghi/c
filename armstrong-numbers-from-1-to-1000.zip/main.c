/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<stdio.h>
#include<math.h>
int main()
{
    int i, sum, num, count = 0;
    printf("All Armstrong number between 1 and 1000 are : ");
    for (i = 1; i <= 1000; i++) {
        num = i;
        while (num != 0) {
            num /= 10;
            count++;
        }
        num = i;
        sum = pow(num % 10, count)
             + pow((num % 100 - num % 10) / 10, count)
             + pow((num % 1000 - num % 100) / 100, count);
        if (sum == i) 
        {
        printf(" %d ", i);
        }
        count = 0;
    }
    return 0;
}
