/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main() 

{
    int k=10,i;    
    int array[]={1,21,32,101,13,10,20};
    int n=sizeof(array)/sizeof(array[0]);
    int found=0;
    for (i=0;i<n;i++) 
    {
        if (array[i] == k) 
        {
            printf("Element %d found at the index %d", k,i);
            found = 1;
            break;
        }
    }
    if (!found) 
    {
        printf("Element %d not found", k);
    }
    return 0;
}