/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int i,j,count;
    char str[20],rev[20];
    printf("enter the string : ");
    scanf("%s",str);
    count=0;
    while(str[count])
    {
        count++;
    }
    j=count-1;
    for(i=0;i<count;i++)
    {
        rev[i]=str[j];
        j--;
    }
    printf("reverse of string : %s",rev);
    return 0;
}
