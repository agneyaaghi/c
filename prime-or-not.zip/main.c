/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int main()
{
    int i,num,temp=0; 
    printf("Enter the number:");
    scanf("%d",&num);
    for (i=2;i<= num/2;i++)
    {
        if(num%i==0)
        {
            temp++;
            break;
        }
    } 
    if(temp==0&&num!=1)
    {
        printf("%d is a Prime number",num);
    }
    else
    {
        printf("%d is not a Prime number",num);
    }
    return 0;
}