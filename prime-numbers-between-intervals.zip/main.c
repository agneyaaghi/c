/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int main()
{
   int l, h, i, f;
   printf("Enter two numbers : ");
   scanf("%d %d", &l, &h);
   printf("Prime numbers between %d and %d are : ", l, h);
   while (l < h)
   {
   f = 0;
      if (l <= 1) 
      {
         ++l;
         continue;
      }
   for (i = 2; i <= l / 2; ++i)
   {
         if (l % i == 0) 
         {
            f = 1;
            break;
         }
      }
      if (f == 0)
         printf("%d ", l);
      ++l;
   }
    return 0;
}