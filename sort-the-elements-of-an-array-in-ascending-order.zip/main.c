/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int main()
{
    int i, j, a, n, number[30];
    printf("Enter the num : ");
    scanf("%d", &n);
    printf("Enter the numbers : ");
    for (i = 0; i < n; ++i)
    scanf("%d", &number[i]);
    for (i = 0; i < n; ++i) 
        {
        for (j = i + 1; j < n; ++j)
        {
        if (number[i] > number[j]) 
            {
                a =  number[i];
                number[i] = number[j];
                number[j] = a;
                }
            }
        }
    printf("The numbers arranged in ascending order : ");
    for (i = 0; i < n; ++i)
    printf("%d ", number[i]);
    return 0;
}