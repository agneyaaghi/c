/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int isprime(int num)

{
    int i;
    for(i=2;i<num;i++)
    {
        if(num%i==0)
        {
            return 0;
        }
    }
    return 1;
}

int main()
{
    int num;
    printf("enter the number : ");
    scanf("%d",&num);
    if(isprime(num))
    {
        printf("prime number");
    }
    else
    {
        printf("not prime");
    }

    return 0;
}