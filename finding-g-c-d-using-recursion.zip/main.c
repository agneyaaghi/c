/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int gcd(int a,int b)

{
    if(b==0) {
        return a;
    } else 
    {
        return gcd(b,a%b);
    }
}

int main()

{
    int num1,num2;
    printf("Enter two positive integers : ");
    scanf("%d %d",&num1,&num2);
    if (num1<=0||num2<=0) 
    {
        printf("it is not a positive integers \n");
        return 1; 
    }
    printf("The GCD is %d \n",gcd(num1, num2));
    return 0;
}
