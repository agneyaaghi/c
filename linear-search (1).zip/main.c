/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()

{    
    int n,i,s;
    
    printf("enter the number of element : ");
    scanf("%d",&s);
    
    int arr[s];
    printf("enter the elements: ");
    for(i=0;i<s;i++){
        scanf("%d",&arr[i]);
    }
    
    printf("enter the number to search : ");
    scanf("%d",&n);
    
    //linear search
    for(i=0;i<s;i++){
        if(arr[i]==n){
            printf("element %d found",n);
            return 0;
        }
    }
    
    if(i==s){
            printf("element not found");
        }

    return 0;
}