/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int power(int n1, int n2);
int main() 
{
    int base,a,result;
    printf("Enter base number : ");
    scanf("%d",&base);
    printf("Enter power number : ");
    scanf("%d",&a);
    result=power(base,a);
    printf("%d^%d=%d",base,a,result);
    return 0;
}
int power(int base,int a) 
{
    if(a!=0)
        return(base*power(base,a-1));
    else
        return 1;
}