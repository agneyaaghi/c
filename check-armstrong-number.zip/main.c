/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int main() {
    int num, orgNum, r, n = 0;
    int result = 0;
    printf("Enter an integer: ");
    scanf("%d", &num);
    orgNum = num;
    while (orgNum != 0) 
    {
        orgNum /= 10;
        ++n;
    }
    orgNum = num;
    while (orgNum != 0) 
    {
        r= orgNum % 10;
        int power = 1;
        for(int i = 0; i < n; i++) {
        power*=r;
    }
        result += power;
        orgNum /= 10;
    }
    if (result == num)
        printf("%d is an Armstrong number.\n", num);
    else
        printf("%d is not an Armstrong number.\n", num);
    return 0;
}