/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int array1[] = {3,5,8,7,9};
    int array2[] = {1,2,5,8,10};
    int i, j, f, x, k = 0;
    int result[100];
    printf("Common elements are : ");
    for (i = 0; i < sizeof(array1) / 4; i++) 
    {
        for (j = 0; j < sizeof(array2) / 4; j++)
        {
            if (array1[i] == array2[j])
            {
                f = 0;
                for (x = 0; x < k; x++)
                {
                    if (result[x] == array1[i]) 
                    {
                        f++;
                    }
                }
                if (f== 0) 
                {
                   
                    result[k] = array1[i];
                    printf("%d ", result[k]);
                    k++;
                }
            }
        }
    }

    return 0;
}
