/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int main()
{
    int n,i;
    float num[100],sum=0,avg;
    printf("Enter the numbers of elements : ");
    scanf("%d",&n);
    while(n>100||n<1)
    {
        printf("Enter the number : ");
        scanf("%d", &n);
    }
    for(i=0;i<n;++i) 
    {
        printf("Enter number %d : ",i+1);
        scanf("%f",&num[i]);
        sum+=num[i];
    }
    avg=sum/n;
    printf("Average = %.2f",avg);
    return 0;
}
