/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int main()

{
    int a;
    int arr[]={3,4,6,9,12,15,16,20};
    int left=0;
    int right=(sizeof(arr)/sizeof(arr[0]))-1;
    printf("enter the element to search: ");
    scanf("%d",&a);
    while(left<=right){
        int middle=(left+right)/2;
        
        if(arr[middle]==a)
        {
            printf("%d The searched element is found",a);
            break;
            
        }
        else if(arr[middle]>a)
        right=middle-1;
        else
        left=middle+1;
    }
    printf("The searched element is not found");
    return 0;
}