/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <math.h> 
void main(){
    int n1, df, n2, i, ln; 
    int s1 = 0; 
    printf("Input  the starting number of the A.P series : ");
    scanf("%d", &n1); 
    printf("Input the number of items : "); 
    scanf("%d", &n2); 
    printf("Input the common difference : "); 
    scanf("%d", &df); 
    s1 = (n2 * (2 * n1 + (n2 - 1) * df)) / 2;
    ln = n1 + (n2 - 1) * df; 
    printf("\n The Sum is : \n"); 
    for (i = n1; i <= ln; i = i + df) {
         if (i != ln)
             printf("%d + ", i); 
         else
             printf("%d = %d \n\n", i, s1); 
    }
}