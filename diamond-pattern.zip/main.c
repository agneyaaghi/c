/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int main()
{
     int i, j, rows, k;  
    printf (" Enter the numberof  rows : ");  
    scanf("%d", &rows);   
    int s = rows-1, num=1;  
    printf("\n");  
    for (i = 1; i <= rows; i++)   
    {  
        for (j = 1; j <= s; j++)   
        {  
            printf("  "); 
        }  
        for ( k= 1; k <= num; k++)  
        {  
            printf(" *");  
        }  
        if(s > i)  
        {  
            s = s -1;  
            num = num+2;  
        }  
        if(s <i)  
        {  
            s = s + 1;  
            num = num -2;  
        }  
        printf("\n");  
    }  

    return 0;
}
