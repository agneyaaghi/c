/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
  
    int matrix[2][2]={{2,4},{5,6}};
    int i,j;
    for(i=0;i<2;i++)
    {
        for(j=0;j<2;j++)
        {
           printf(" %d ",matrix[i][j]);
        }
        printf("\n");
    }
    return 0;
}