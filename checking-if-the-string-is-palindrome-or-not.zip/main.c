/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <string.h>
int main()
{
    char string1[20];
    int i,length;
    int f=0;
    printf("Enter a string : ");
    scanf("%s",string1);
    length=strlen(string1);
    for(i=0;i<length/2;i++) {
    if(string1[i]!=string1[length-i-1]) 
    {
        f=1;
        break;
    }
    }
    if(f) 
    {
        printf("it is not a palindrome");
    } else {
        printf("it is a palindrome");
    }
    return 0;
}