/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int factorial(int n) 
{
    if (n <= 1) 
    {
        return 1;
    } else
    {
        return n * factorial(n - 1);
    }
}
int main() 
{
    int num;
    printf("Enter a positive integer : ");
    scanf("%d", &num);
    if (num < 0) 
    {
        printf("Factorial is not defined \n");
        return 1; 
    }
    printf("The factorial is %d \n",factorial(num));
    return 0;
}