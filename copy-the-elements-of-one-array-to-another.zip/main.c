/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h> 
int main()
{
    int i,size;
    printf("Enter the number of elements : ");
    scanf("%d",&size);
    int firstArray[size];
    int secondArray[size];
    printf("Enter elements for first array : ");
    for(i=0;i<size;i++) 
    {
        scanf("%d",&firstArray[i]);
    }
    for(i=0;i<size;i++) {
        secondArray[i]=firstArray[i];
    }
    printf("second Array : ");
    for(i=0;i<size;i++) {
    printf("%d ", secondArray[i]);
    }
    printf("\n");
    return 0;
}