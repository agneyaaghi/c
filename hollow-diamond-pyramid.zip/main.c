/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int main()
{
    int  r, c,n;
    printf("enter the number of rows : ");
    scanf("%d",&n);
    for (r = 1; r <= n; r++) {
        for (c = n; c > r; c--) {
            printf(" ");
        }
        printf("*");
        for (c = 1; c < (r - 1) * 2;c++) {
            printf(" ");
        }
        if (r == 1) {
            printf("\n");
        }
        else {
            printf("*\n");
        }
    }
    for (r = n - 1; r >= 1; r--) {
        for (c = n; c > r; c--) {
            printf(" ");
        }
        printf("*");
        for (c = 1; c < (r - 1) * 2;c++) {
            printf(" ");
        }
        if (r == 1) {
            printf("\n");
        }
        else {
            printf("*\n");
        }
    }
    return 0;
}