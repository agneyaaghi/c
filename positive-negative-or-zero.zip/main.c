/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int main()
{
int number;
    printf("Enter an integer : ");
    scanf("%d", &number);
    if (number > 0) 
    {
        printf("Number is positive.\n");
    } 
    else if (number < 0) {
        printf("Number is negative.\n");
    } 
    else {
        printf("Number is zero.\n");
    }
    return 0;
}