/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()

{
    int fib,i,n;
    printf("enter the limit : ");
    scanf("%d",&n);
    int a=0,b=1;
    printf("%d %d",a,b);
    for(i=2;i<=n;i++)
    {
        fib=a+b;
        printf(" %d",fib);
        a=b;
        b=fib;
    }
    return 0;
}